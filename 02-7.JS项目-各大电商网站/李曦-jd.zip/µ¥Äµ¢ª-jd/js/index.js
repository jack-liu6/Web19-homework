// 控制顶部搜索栏的显示与隐藏
// window.onscroll = function() {
//     console.log("页面滚动了");
//     //1.获取滚动条滚动的距离
//     var top = document.documentElement.scrollTop;
//     console.log(top);
//     // 2.获取到顶部div  class= header
//     var search_nav = document.getElementsByClassName('search_nav')[0];

//     // 假设top为150时， header_middle出现了
//     if (top >= 150) {
//         search_nav.style.position = "fixed";
//         search_nav.style.top = "0";
//         search_nav.style.height = "52px";
//         search_nav.style.display = "block";
//         search_nav.style.zIndex = 1000;
//     } else {
//         search_nav.style.display = "none";
//         search_nav.style.height = "0";

//     }
// }
window.onload = function() {

    function $(id) {
        return document.getElementById(id);
    }
    // shortcut 的下拉菜单部分
    // 控制地址的显示与隐藏
    $('cityDD').onmouseover = function() {
        $('citydd').style.display = 'block';
    }
    $('cityDD').onmouseout = function() {
            $('citydd').style.display = 'none';
        }
        // 选择城市
    var dizhi = document.querySelector("#dizhi");
    var dizhi_span = document.querySelector("#dizhi-span");
    var cityd1 = document.querySelector("#cityd1");
    var cityd1c = cityd1.querySelectorAll(".cityd1c");
    for (var i = 0; i < cityd1c.length; i++) {
        cityd1c[i].onclick = function() {
            dizhi_span.innerText = this.innerText;
        }
    }
    // 我的京东
    $('shortcut-myjd').onmouseover = function(e) {
        $('myjd-list').style.display = 'block';
    }
    $('shortcut-myjd').onmouseout = function(e) {
            $('myjd-list').style.display = 'none';
        }
        // 企业采购
    $('purchase').onmouseover = function(e) {
        $('purchase-dd').style.display = 'block';
    }
    $('purchase').onmouseout = function(e) {
            $('purchase-dd').style.display = 'none';
        }
        // 客户服务
    $('customer-service').onmouseover = function(e) {
        $('customer-service-dd').style.display = 'block';
    }
    $('customer-service').onmouseout = function(e) {
            $('customer-service-dd').style.display = 'none';
        }
        //网站导航
    $('webnav').onmouseover = function(e) {
        $('webnav-dd').style.display = 'block';
    }
    $('webnav').onmouseout = function(e) {
            $('webnav-dd').style.display = 'none';
        }
        // 手机京东

    $('mobileLi').onmouseover = function(e) {
        $('mobile-popout').style.display = 'block';
    }
    $('mobileLi').onmouseout = function(e) {
        $('mobile-popout').style.display = 'none';
    }


    // 二级菜单
    var grid_col1_ul = document.querySelector(".grid-col1-ul").children;
    for (var i = 0; i < grid_col1_ul.length; i++) {
        grid_col1_ul[i].onmouseover = function() {
            // e.stoppropagation();
            this.lastElementChild.style.display = "block";
        }
        grid_col1_ul[i].onmouseout = function() {
            // e.stoppropagation();
            this.lastElementChild.style.display = "none";
        }
    }
    // 定时切换logo路径
    // 2.使用定时器实现这两个图的定时切换
    //每隔2秒切换img的src的图片地址
//  var curIndex = 0;
//  var timeInterval = 2000;
//  var arr = new Array();
//  arr[0] = "../images/logo.gif";
//  arr[1] = "../images/logo2.gif";
//  arr[2] = "../images/logo3.gif";
//  arr[3] = "../images/logo4.gif";
//  setInterval("changeImg()", timeInterval);
//  function changeImg() {
//      var obj = document.getElementById("mylogo");
//      if (curIndex == arr.length-1) {
//          curIndex = 0;
//      } else {
//          curIndex += 1;
//      }
//      obj.src= arr[curIndex];
//  }



    // function getStyle(obj, name) {
    //     return window.getComputedStyle ? getComputedStyle(obj, null)[name] : obj.currentStyle[name];

    // }

    // prev2.onclick = function() {
    //     clearInterval(timer);
    //     timer = setInterval(function() {
    //         var oldvalue = parseInt(getStyle(slide2ul, 'left'));
    //         var newvalue = oldvalue - 10;
    //         if (newvalue < -802) {
    //             newvalue = 0;
    //         }
    //         slide2ul.style.left = newvalue + 'px';
    //         if (newvalue == -800) {
    //             clearInterval(timer);
    //         }
    //     }, 30)
    // }


    // next2.onclick = function() {
    //     clearInterval(timer);
    //     timer = setInterval(function() {
    //         var oldvalue = parseInt(getStyle(slide2ul, 'left'));
    //         var newvalue = oldvalue + 10;
    //         if (newvalue > 800) {
    //             newvalue = 800;
    //         }
    //         slide2ul.style.left = newvalue + 'px';
    //         if (newvalue == 0) {
    //             clearInterval(timer);
    //         }
    //     }, 30)

    // };





    // 大图轮播
    function focus() {
        var grid_col2_l = document.querySelector(".grid-col2-l ");
        var picList = grid_col2_l.querySelector(".picList");
        var arrowL = grid_col2_l.querySelector(".arrow-l");
        var arrowR = grid_col2_l.querySelector(".arrow-r");
        var circle = grid_col2_l.querySelectorAll(".circle li");
        var index = 0;

        // 上一张
        arrowL.onclick = function() {
            index--;
            if (index < 0) {
                index = 7;
            }
            picList.style.left = -590 * index + "px";
            for (var j = 0; j < circle.length; j++) {
                circle[j].className = "";
                circle[index].className = "current";
            }
        };
        // 下一张
        arrowR.onclick = function() {
            index++;
            if (index > 7) {
                index = 0;
            }
            picList.style.left = -590 * index + "px";
            for (var j = 0; j < circle.length; j++) {
                circle[j].className = "";
                circle[index].className = "current";
            }
        };
        for (var i = 0; i < circle.length; i++) {
            // square[i].index = i;
            circle[i].setAttribute("index", i);
            circle[i].onclick = function() {
                index = this.getAttribute("index");
                picList.style.left = -590 * index + "px";
                for (var j = 0; j < circle.length; j++) {
                    circle[j].className = "";
                    this.className = "current";
                }
            }
        }

        function go() {
            arrowR.onclick();
        }
        var timer = setInterval(go, 2000);
        grid_col2_l.onmouseover = function() {
            clearInterval(timer);
        }
        grid_col2_l.onmouseout = function() {
            timer = setInterval(go, 2000);
        }
    }
    focus();
    // 右侧小图轮播
    function xiaotu() {
        var grid_col2_r = document.querySelector(".grid-col2-r");
        var grid_col2_r_ul = grid_col2_r.querySelector(".grid-col2-r-ul");
        var controlL = grid_col2_r.querySelector(".control-l");
        var controlR = grid_col2_r.querySelector(".control-r");
        var index = 0;
        // 上一张
        controlL.onclick = function() {
            index--;
            if (index < 0) {
                index = 2;
            }
            grid_col2_r_ul.style.left = -190 * index + "px";
        };
        // 下一张
        controlR.onclick = function() {
            index++;
            if (index > 2) {
                index = 0;
            }
            grid_col2_r_ul.style.left = -190 * index + "px";
        };

        function go() {
            controlR.onclick();
        }
        var timer = setInterval(go, 3000);
        grid_col2_r_ul.onmouseover = function() {
            clearInterval(timer);
        }
        grid_col2_r_ul.onmouseout = function() {
            timer = setInterval(go, 3000);
        }
    }
    xiaotu();
    // 秒杀轮播
    function secpic() {
        var slider_list = document.querySelector(".slider-list");
        var slider_list_ul = slider_list.querySelector(".slider-list-ul");
        var SLAL = slider_list.querySelector(".slider-list-a-l");
        var SLAR = slider_list.querySelector(".slider-list-a-r");
        var index = 0;
        // 上一张
        SLAL.onclick = function() {
            index--;
            if (index < 0) {
                index = 2;
            }
            slider_list_ul.style.left = -800 * index + "px";
        };
        // 下一张
        SLAR.onclick = function() {
            index++;
            if (index > 2) {
                index = 0;
            }
            slider_list_ul.style.left = -800 * index + "px";
        };

        function go() {
            SLAR.onclick();
        }
        var timer = setInterval(go, 1500);
        slider_list_ul.onmouseover = function() {
            clearInterval(timer);
        }
        slider_list_ul.onmouseout = function() {
            timer = setInterval(go, 1500);
        }
    }
    secpic()

    //倒计时效果
    //通过定时器每隔1s执行一次
    setInterval(function() {
        //Date不添加参数，则表示现在的时间
        var d = new Date();
        // Date添加一个时间日期参数，则表示未来或过去的时间
        var past = new Date('2020-8-9 08:53:03'); //过去的时间戳
        var future = new Date('2020-8-16 08:53:39');

        // 将未来的时间减去现在此时此刻的时间就是这两个时间的时间差（返回的是毫秒数）
        var cha = future - d;

        // 如果要转成秒数，则需要除以1000，也就是8月7日距离现在还有2678308秒
        // 1s=1000ms
        var chas = parseInt(cha / 1000); //2678308
        // 接下来就需要将这个秒数换算成 x天x时x分x秒

        var day = parseInt(chas / 3600 / 24); //得到多少天了

        var hours = parseInt(chas / 3600 % 24); //小时
        // console.log(hours); //23

        // 
        var min = parseInt(chas % 3600 / 60); //分钟
        // console.log(min); //21

        var sec = chas % 60;
        // console.log(sec); //11

        // console.log("距离还剩："+day+"天"+hours+"时"+min+"分"+sec+"秒");
        var cd = document.querySelector(".countdown-desc");
        var cd_hd = cd.querySelector(".cd_hd");
        var timer_unit_hour = cd.querySelector(".timer_unit--hour");
        var timer_unit_min = cd.querySelector(".timer_unit--min");
        var timer_unit_sec = cd.querySelector(".timer_unit--sec");
        var timer_unit = cd.querySelector(".timer_unit");
        cd_hd.innerText = (hours + 1) + ":00" + "点场 倒计时";
        // document.querySelector(".countdown-desc").innerText = hours + "时" + min + "分" + sec + "秒";
        // timer_unit.innerText = hours + "时" + min + "分" + sec + "秒";
        timer_unit_hour.innerText = hours;
        timer_unit_min.innerText = min;
        timer_unit_sec.innerText = sec;

    }, 1000);
    // tab切换页

    var floor_first_tab = document.querySelector(".floor-first-tab").children;
    var floor_first_tab_bd = document.querySelector(".floor-first-tab-bd").children;

    function tabs() {
        for (var i = 0; i < floor_first_tab.length; i++) {
            floor_first_tab[i].index = i;
            floor_first_tab[i].onmouseover = function() {
                for (var j = 0; j < floor_first_tab_bd.length; j++) {
                    floor_first_tab[j].style = " border-bottom: none";
                    floor_first_tab_bd[j].style.display = "none";
                }
                this.style = " border-bottom: 2px solid #e1251b;";
                floor_first_tab_bd[this.index].style.display = "block";
            }
        }
    }
    tabs();

    // 频道广场  
    var channel_floor_ul = document.querySelector(".channel-floor-ul").children;
    console.log(channel_floor_ul);

    function showFocus() {
        for (var i = 0; i < channel_floor_ul.length; i++) {
            channel_floor_ul[i].onmouseover = function() {
                for (var j = 0; j < channel_floor_ul.length; j++) {
                    channel_floor_ul[j].style.opacity = 0.4;
                }
                this.style.opacity = 1;
            }
            channel_floor_ul[i].onmouseleave = function() {
                for (var j = 0; j < channel_floor_ul.length; j++) {
                    channel_floor_ul[j].style.opacity = 1;
                }
                this.style.opacity = 1;
                // channel_floor_ul[i].style.opacity=1;
            }
        }
    }
    showFocus();

    // 为你推荐
    var recom_bd_ul = document.querySelector(".recom-bd-ul").children;
    var recom_bd_del = document.querySelectorAll(".recom-bd-del");
    console.log(recom_bd_del);
    var recom_bd_find = document.querySelectorAll(".recom-bd-find");
    console.log(recom_bd_find);

    function findDel() {
        for (var i = 0; i < recom_bd_ul.length; i++) {
            recom_bd_ul[i].index = i;
            recom_bd_ul[i].onmouseover = function() {
                recom_bd_del[this.index].style.display = "block";
                recom_bd_find[this.index].style.display = "block";
            }
            recom_bd_ul[i].onmouseout = function() {
                recom_bd_del[this.index].style.display = "none";
                recom_bd_find[this.index].style.display = "none";
            }
        }
    }
    findDel();

}