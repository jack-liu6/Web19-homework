window.onload = function() {
    // 二维码
    var qrcode = document.querySelector(".qrcode");
    var orange_phone = document.querySelector(".orange-phone");
    qrcode.onmouseover = function() {
        qrcode.style.left = "22px";
        orange_phone.style.display = "block";
    }
    qrcode.onmouseout = function() {
            qrcode.style.left = "86px";
            orange_phone.style.display = "";
        }
        // // 登陆页切换
        // var login_tab_l = document.querySelector(".login-tab-l");
        // var login_tab_r = document.querySelector(".login-tab-r");
        // var scan_qrcode = document.querySelector(".scan-qrcode");
        // var login_form_ipt = document.querySelector(".login-form-ipt");
    function $(id) {
        return document.getElementById(id);
    }

    // 控制显示与隐藏
    $('login-tab-l').onmouseover = function() {
        $('scan-qrcode').style.display = 'block';
    }
    $('login-tab-l').onmouseout = function() {
            $('scan-qrcode').style.display = 'none';
    }



    // var login_tab_hd = document.querySelector(".login-tab-hd").children;
    // var login_tab_bd = document.querySelector(".login-tab-bd").children;
    // console.log(login_tab_hd);
    // console.log(login_tab_bd);
    // function loginTabs() {
    //     for (var i = 0; i < login_tab_hd.length; i++) {
    //         login_tab_hd[i].index = i;
    //         login_tab_hd[i].onclick = function() {
    //             for (var j = 0; j < login_tab_hd.length; j++) {
    //                 console.log(7878);
    //                 login_tab_hd[j].style.className= "";
    //                 login_tab_bd[j].style.display = "none";
    //             }
    //             this.style.className = "f10";
    //             login_tab_bd[this.index].style.display = "block";
    //         }
    //     }
    // }
    // loginTabs();
}