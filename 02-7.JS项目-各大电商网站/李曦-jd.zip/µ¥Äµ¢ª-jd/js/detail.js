window.onload = function() {

    function $(id) {
        return document.getElementById(id);
    }
    // shortcut 的下拉菜单部分
    // 控制地址的显示与隐藏
    $('cityDD').onmouseover = function() {
        $('citydd').style.display = 'block';
    }
    $('cityDD').onmouseout = function() {
            $('citydd').style.display = 'none';
        }
        // 选择城市
    var dizhi = document.querySelector("#dizhi");
    var dizhi_span = document.querySelector("#dizhi-span");
    var cityd1 = document.querySelector("#cityd1");
    var cityd1c = cityd1.querySelectorAll(".cityd1c");
    for (var i = 0; i < cityd1c.length; i++) {
        cityd1c[i].onclick = function() {
            dizhi_span.innerText = this.innerText;
        }
    }
    // 我的京东
    $('shortcut-myjd').onmouseover = function(e) {
        $('myjd-list').style.display = 'block';
    }
    $('shortcut-myjd').onmouseout = function(e) {
            $('myjd-list').style.display = 'none';
        }
        // 企业采购
    $('purchase').onmouseover = function(e) {
        $('purchase-dd').style.display = 'block';
    }
    $('purchase').onmouseout = function(e) {
            $('purchase-dd').style.display = 'none';
        }
        // 客户服务
    $('customer-service').onmouseover = function(e) {
        $('customer-service-dd').style.display = 'block';
    }
    $('customer-service').onmouseout = function(e) {
            $('customer-service-dd').style.display = 'none';
        }
        //网站导航
    $('webnav').onmouseover = function(e) {
        $('webnav-dd').style.display = 'block';
    }
    $('webnav').onmouseout = function(e) {
            $('webnav-dd').style.display = 'none';
        }
        // 手机京东

    $('mobileLi').onmouseover = function(e) {
        $('mobile-popout').style.display = 'block';
    }
    $('mobileLi').onmouseout = function(e) {
            $('mobile-popout').style.display = 'none';
        }
        //手机品牌选择
        //   $('choose_phoneBrand').onmouseover = function(e) {
        //      $('phone-link').style.height = 184+"px";
        //  }
        //  $('choose_phoneBrand').onmouseout = function(e) {
        //      $('phone-link').style.height = 0;
        //  }
        //菜单导航栏
    var menu_nav_MAC_dd_ul = document.querySelector(".menu-nav-MAC-dd-ul").children;
    var menu_nav_MAC_dd = document.querySelector(".menu-nav-MAC-dd");

    function navMenu() {
        for (var i = 0; i < menu_nav_MAC_dd_ul.length; i++) {
            menu_nav_MAC_dd_ul[i].onmouseover = function() {
                for (var j = 0; j < menu_nav_MAC_dd.length; j++) {
                    menu_nav_MAC_dd[j].style.display = "none";
                }
                this.lastElementChild.style.display = "block";
            }
            menu_nav_MAC_dd_ul[i].onmouseleave = function() {
                    for (var j = 0; j < menu_nav_MAC_dd.length; j++) {
                        menu_nav_MAC_dd[j].style.display = "none";
                    }
                    this.lastElementChild.style.display = "none";
                }
                //  			menu_nav_MAC_dd_ul[i].onmouseleave=function(){
                //  				for(var j=0;j< menu_nav_MAC_dd.length;j++){
                //  					menu_nav_MAC_dd[i].style.display="none";
                //  				}
                ////  				this.lastElementChild.style.display="none";
                //  				menu_nav_MAC_dd[this.index].style.display="none";
                //  			}	
        }
    }
    navMenu();
    // 产品选择信息
    var choose_color_dd = document.querySelector(".choose_color-dd").children;
    console.log(choose_color_dd);
    for (var i = 0; i < choose_color_dd.length; i++) {
        choose_color_dd[i].onclick = function() {
            for (var j = 0; j < choose_color_dd.length; j++) {
                choose_color_dd[j].style.className = "";
                console.log(4455);
            }
            this.style.className = "current";
        }

    }



    // tab_list
    // var tab_list = document.querySelector(".tab_list");
    // tab切换页

    var tab_list_ul = document.querySelector(".tab_list_ul").children;
    console.log(tab_list_ul);
    var tab_con = document.querySelector(".tab_con").children;
    console.log(tab_con);

    function tabs() {
        for (var i = 0; i < tab_list_ul.length; i++) {
            tab_list_ul[i].index = i;
            tab_list_ul[i].onmouseover = function() {
                for (var j = 0; j < tab_list_ul.length; j++) {
                    tab_list_ul[j].style.className = "";
                    tab_con[j].style.display = "none";

                }
                this.style.className = "current";
                tab_con[this.index].style.display = "block";
            }
        }
    }
    tabs();
    //商品介绍切换
    var detail_tab_list_ul=document.querySelectorAll(".detail_tab_list_ul>li");
    console.log(detail_tab_list_ul);
    var detail_tab_con=document.querySelector(".detail_tab_con").children;
    console.log(detail_tab_con);
     function Tabs() {
        for (var i = 0; i < detail_tab_list_ul.length; i++) {
            detail_tab_list_ul[i].index = i;
            detail_tab_list_ul[i].onclick = function() {
                for (var j = 0; j < tab_list_ul.length; j++) {
                    detail_tab_list_ul[j].style.className = "";
                    detail_tab_con[j].style.display = "none";
                }
                this.style.className = "detail_tab_list current";
                detail_tab_con[this.index].style.display = "block";
            }
        }
    }
   Tabs();
    


}



//放大镜

window.addEventListener('load', function() {
    var preview_img = document.querySelector('.preview_img');
    var mask = document.querySelector('.mask');
    var big = document.querySelector('.big');
    // 1. 当我们鼠标经过 preview_img 就显示和隐藏 mask 遮挡层 和 big 大盒子
    preview_img.addEventListener('mouseover', function() {
        mask.style.display = 'block';
        big.style.display = 'block';
    })
    preview_img.addEventListener('mouseout', function() {
            mask.style.display = 'none';
            big.style.display = 'none';
        })
        // 2. 鼠标移动的时候，让黄色的盒子跟着鼠标来走
    preview_img.addEventListener('mousemove', function(e) {
        // (1). 先计算出鼠标在盒子内的坐标
        var x = e.pageX - this.offsetLeft;
        var y = e.pageY - this.offsetTop;
        // console.log(x, y);
        // (2) 减去盒子高度 300的一半 是 150 就是mask 的最终 left 和top值了
        // (3) mask 移动的距离
        var maskX = x - mask.offsetWidth / 2;
        var maskY = y - mask.offsetHeight / 2;
        // (4) 如果x 坐标小于了0 就让他停在0 的位置
        // 遮挡层的最大移动距离
        var maskMax = preview_img.offsetWidth - mask.offsetWidth;
        if (maskX <= 0) {
            maskX = 0;
        } else if (maskX >= maskMax) {
            maskX = maskMax;
        }
        if (maskY <= 0) {
            maskY = 0;
        } else if (maskY >= maskMax) {
            maskY = maskMax;
        }
        mask.style.left = maskX + 'px';
        mask.style.top = maskY + 'px';
        // 3. 大图片的移动距离 = 遮挡层移动距离 * 大图片最大移动距离 / 遮挡层的最大移动距离
        // 大图
        var bigIMg = document.querySelector('.bigImg');
        // 大图片最大移动距离
        var bigMax = bigIMg.offsetWidth - big.offsetWidth;
        // 大图片的移动距离 X Y
        var bigX = maskX * bigMax / maskMax;
        var bigY = maskY * bigMax / maskMax;
        bigIMg.style.left = -bigX + 'px';
        bigIMg.style.top = -bigY + 'px';

    })
    var arrow_prev = document.querySelector(".arrow_prev");
    var arrow_next = document.querySelector(".arrow_next");
    var list_item = document.querySelector(".list_item");
    var index = 0;
    //
    // 上一张
    // arrowL.onclick = function() {
    //     index--;
    //     if (index < 0) {
    //         index = 7;
    //     }
    //     picList.style.left = -590 * index + "px";
    //     for (var j = 0; j < circle.length; j++) {
    //         circle[j].className = "";
    //         circle[index].className = "current";
    //     }
    // };
    //小火箭
    var rocket = document.getElementById("rocket");

    rocket.onclick = function() {
        // var speed=5;
        // 读：读取当前滚动条的位置信息
        var top = document.documentElement.scrollTop; //100
        var timer = setInterval(function() {
            // speed+
            top -= 5;
            console.log(1)
                // scrollTop是可读写的！！
                // 写，改变滚动条的位置
            document.documentElement.scrollTop = top;
            if (top <= 0) {
                clearInterval(timer);
            }
        }, 10);
    }


})