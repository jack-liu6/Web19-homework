window.onload = function() {
    // 头部的隐藏部分
    var dis_1 = document.querySelectorAll(".dis")
    var dichu = document.querySelectorAll(".over")
    var guo = document.querySelectorAll(".dalu")
    for (i = 0; i < dichu.length; i++) {
        dichu[i].indox = i
        dichu[i].onmouseover = function() {
            guo[this.indox].style.backgroundColor = " #ffffff"
            dis_1[this.indox].style.display = "block"
        }
        dichu[i].onmouseout = function() {
            guo[this.indox].style.backgroundColor = ""
            dis_1[this.indox].style.display = "none"
        }
    }
    // 更多市场
    var gengduo = document.querySelector(".gengduo")
    var gengduoul = document.querySelector(".gengduoul")
    gengduo.onmouseover = function() {
        gengduoul.style.display = "block"
    }
    gengduo.onmouseout = function() {
            gengduoul.style.display = "none"
        }
        // 所有分类
    var suoyoufl = document.querySelector(".suoyoufl")
    var jundiu = document.querySelector(".jundiu")
    suoyoufl.onmouseover = function() {
        jundiu.style.display = "block"
    }
    suoyoufl.onmouseout = function() {
            jundiu.style.display = "none"
        }
        // 放大镜效果
    var sdiv = document.querySelector(".imga");
    var oSpan = document.querySelector("#ospan")
    var bdiv = document.querySelector(".bdiv");
    var bimg = document.querySelector(".bdiv>img");
    console.log(getPos(sdiv).top)
    sdiv.onmousemove = function(e) {
        var l = e.pageX - getPos(this).left - oSpan.offsetWidth / 2;
        var t = e.pageY - getPos(this).top - oSpan.offsetHeight / 2;
        var L = sdiv.clientWidth - oSpan.offsetWidth;
        var T = sdiv.clientHeight - oSpan.offsetHeight;
        if (l < 0) {
            l = 0;
        }
        if (l > L) {
            l = L;
        }
        if (t < 0) {
            t = 0;
        }
        if (t > T) {
            t = T;
        }
        oSpan.style.left = l + "px";
        oSpan.style.top = t + "px";
        var bx = (bimg.clientWidth - bdiv.clientWidth) / (sdiv.clientWidth - oSpan.offsetWidth);
        var by = (bimg.clientHeight - bdiv.clientHeight) / (sdiv.clientHeight - oSpan.offsetHeight);

        bimg.style.left = -l * bx + "px";
        bimg.style.top = -t * by + "px";

    }
    sdiv.onmouseover = function() {
        oSpan.style.display = bdiv.style.display = "block";
    };
    sdiv.onmouseout = function() {
        oSpan.style.display = "none";
        bdiv.style.display = "none";
    };

    function getPos(ele) {
        var l = 0;
        var t = 0;
        while (ele.offsetParent) {
            l += ele.offsetLeft + ele.offsetParent.clientLeft;
            t += ele.offsetTop + ele.offsetParent.clientTop;
            ele = ele.offsetParent;
        }
        return {
            'left': l,
            'top': t
        };

    }
    // 地区选择部分
    var xuanzhea = document.querySelector(".xuanzhea")
    var xuanzhediqu = document.querySelectorAll(".diqu-div1 div")
    var diquli = document.querySelectorAll(".diqu-div3 ul li")
    var diquli2 = document.querySelectorAll(".diqu-div2 ul li")
    var diqu_diqu = document.querySelectorAll(".diqu-diqu")
    var diqu = document.querySelector(".diqu")
    var diqu_a = document.querySelector(".diqu .diqu-a")
    xuanzhea.onclick = function() {
            diqu.style.display = "block"
            xuanzhea.style.backgroundColor = "#FF5002"
            xuanzhea.style.color = "#fff"
            for (i = 0; i < diquli.length; i++) {
                diquli[i].onclick = function() {
                    xuanzhediqu[1].style.display = "block"
                    diqu_diqu[0].style.display = "block"
                    diqu_diqu[1].style.display = "none"
                    xuanzhediqu[1].style.borderRight = "1px solid #ff5002"
                    xuanzhediqu[1].style.borderTop = "1px solid #ff5002"
                    xuanzhediqu[1].style.borderLeft = "1px solid #ff5002"
                    xuanzhediqu[0].style.borderRight = "1px solid #e5e5e5"
                    xuanzhediqu[0].style.borderTop = "1px solid #e5e5e5"
                    xuanzhediqu[0].style.borderLeft = "1px solid #e5e5e5"
                }
            }
            for (j = 0; j < diquli2.length; j++) {
                diquli2[j].indox = j
                diquli2[j].onclick = function() {
                    xuanzhea.innerText = "湖南" + diquli2[this.indox].innerText
                    diqu.style.display = "none"
                    xuanzhea.style.backgroundColor = ""
                    xuanzhea.style.color = ""
                }
            }
            diqu_a.onclick = function() {
                diqu.style.display = "none"
                xuanzhea.style.backgroundColor = ""
                xuanzhea.style.color = ""
            }
            return false
        }
        // 免运费
    var yunfeia = document.querySelector(".yunfei a")
    var kuaidi = document.querySelector(".kuaidi")
    yunfeia.onclick = function() {
            kuaidi.style.display = "block"
            yunfeia.style.backgroundColor = "#FF5002"
            yunfeia.style.color = "#fff"
            kuaidi.onclick = function() {
                kuaidi.style.display = "none"
                yunfeia.style.backgroundColor = ""
                yunfeia.style.color = ""

            }
            return false
        }
        // 模二维码
    var youli = document.getElementsByClassName("youli")[0]
    var imgs = document.querySelector(".youli .imgs")
    youli.onmouseover = function() {
        imgs.style.display = "block"
    }
    youli.onmouseout = function() {
            imgs.style.display = "none"
        }
        // 数量加减
    function shuliang() {
        var anniua1 = document.querySelector(".anniu .button1")
        var anniua2 = document.querySelector(".anniu .button3")
        var input = document.querySelector(".anniu .input2")
        anniua1.onclick = function() {
            input.value = Number(input.value) - 1
            if (input.value <= 1) {
                input.value = 1
            }
            return false
        }
        anniua2.onclick = function() {
            input.value = Number(input.value) + 1
            return false
        }
    }
    shuliang()
        // 上面的吸附
    function we() {
        // console.log(div_toubu.offsetTop)
        document.onscroll = function() {
            var guwei = document.querySelector(".guwei")
            var div_toubu = document.querySelector(".div-toubu")
            var xiangqing2 = document.querySelectorAll(".guwei .xiangqing ul .hongse")
            var top = document.documentElement.scrollTop
            if (top >= div_toubu.offsetTop) {
                guwei.style.display = "block"
            } else {
                guwei.style.display = "none"
            }
            for (w = 0; w < xiangqing2.length; w++) {
                xiangqing2[w].indox = w
                xiangqing2[w].onclick = function() {
                    document.documentElement.scrollTop = div_toubu.offsetTop
                    return false
                }
            }

        }
    }
    we()
        //上面吸附的二维码  
    var youli2 = document.getElementsByClassName("youli")[1]
    var imgs2 = document.querySelector(".guwei .youli .imgs")
    youli2.onmouseover = function() {
        imgs2.style.display = "block"
    }
    youli2.onmouseout = function() {
            imgs2.style.display = "none"
        }
        // 弹出框
        // 评论的弹出框
    function tanchu() {
        var xiangqing = document.querySelectorAll(".xiangqing ul .hongse")
        var chulai = document.querySelectorAll(".tanchu .chulai")
        for (i = 0; i < xiangqing.length; i++) {
            xiangqing[i].indox = i
            xiangqing[i].onclick = function() {
                for (j = 0; j < xiangqing.length; j++) {
                    xiangqing[j].className = "hongse"
                }
                xiangqing[this.indox].className = "qing"
                for (h = 0; h < chulai.length; h++) {
                    chulai[h].style.display = "none"
                }
                chulai[this.indox].style.display = "block"
                return false
            }
        }
    }
    tanchu()
        // 评论的好平与全部
    var pinlunul = document.querySelectorAll(".pinlunul input")
    var mingzi = document.querySelectorAll(".mingzi")
    for (f = 0; f < pinlunul.length; f++) {
        pinlunul[f].indox = f
        pinlunul[f].onclick = function() {
            for (t = 0; t < pinlunul.length; t++) {
                pinlunul[t].checked = false
            }
            for (e = 0; e < mingzi.length; e++) {
                mingzi[e].style.display = "none"
            }
            pinlunul[this.indox].checked = true
            mingzi[this.indox].style.display = "block"
        }
    }
}