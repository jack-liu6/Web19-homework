window.onload = function() {
    var bb = document.querySelectorAll(".kuang1 .weima")
    var weima = document.querySelectorAll(".kuang1 .weima a")
    console.log(weima)
    var mimi = document.querySelectorAll(".mimi ")
    weima[0].onclick = function() {
        bb[0].style.display = "none"
        bb[1].style.display = "block"
        weima[1].style.display = "block"
        mimi[0].style.display = "none"
        mimi[1].style.display = "block"
    }
    weima[1].onclick = function() {
        bb[1].style.display = "none"
        bb[0].style.display = "block"
        weima[0].style.display = "block"
        mimi[1].style.display = "none"
        mimi[0].style.display = "block"
    }

    // 登录页与注册页的切换
    var aa = document.querySelectorAll(".shangbu a")
    var chulai = document.querySelectorAll(".chulai")
    for (i = 0; i < aa.length; i++) {
        aa[i].indox = i
        aa[i].onclick = function() {
            for (j = 0; j < chulai.length; j++) {
                chulai[j].style.display = "none"
            }
            for (h = 0; h < aa.length; h++) {
                aa[h].style.borderBottom = "2px solid #F2F7F5"
            }
            aa[this.indox].style.borderBottom = "2px solid #000"
            chulai[this.indox].style.display = "block"
            return false
        }
    }
}