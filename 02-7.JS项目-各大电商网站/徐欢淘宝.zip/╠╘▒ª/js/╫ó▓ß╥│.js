window.onload = function() {
    // 头部的隐藏部分
    function toubu() {
        var dis_1 = document.querySelectorAll(".dis")
        var dichu = document.querySelectorAll(".over")
        var guo = document.querySelectorAll(".dalu")
        for (i = 0; i < dichu.length; i++) {
            dichu[i].indox = i
            dichu[i].onmouseover = function() {
                guo[this.indox].style.backgroundColor = " #ffffff"
                dis_1[this.indox].style.display = "block"
            }
            dichu[i].onmouseout = function() {
                guo[this.indox].style.backgroundColor = ""
                dis_1[this.indox].style.display = "none"
            }
        }
    }
    toubu()
        // 手机号验证


    function shoujihao() {
        var myyonghuming = document.myyonghuming
        var hao = myyonghuming.hao
        var flag = false;
        var submit = document.getElementById("submit")
        myyonghuming.onsubmit = function() {
            return flag;
        }
        var hua = document.getElementById("hua")
        var huankuai = document.getElementById("huankuai")
        var pwd1 = document.getElementById("pwd1")
        hao.onfocus = function() {
            hao.value = ""
        }
        hao.onblur = function() {
            if (hao.value == " " || hao.value.length !== 11 || hao.value.charAt(0) != 1 || isNaN(hao.value)) {
                pwd1.innerText = '格式不正确，请重新输入'
                return flag = false;
                submit.disabled = true

            } else {
                pwd1.innerText = ''
                submit.style.backgroundColor = "#FF4001"
                submit.style.color = "#fff"
                    // submit.disabled = false
                return flag = true;


            }
        }
        hua.onmousedown = function(e) {
            var disx = e.clientX - hua.offsetLeft;
            console.log(disx);
            hua.onmousemove = function(e) {
                console.log(e.clientX);
                hua.style.left = e.clientX - disx + "px";
            }
            hua.onmouseup = function() {
                hua.onmousemove = null;
                if (hua.style.left < 915 + "px" && hua.style.left > 925 + "px") {
                    hua.style.left = 660 + "px"
                    huankuai.style.backgroundColor = "#e8e8e8"
                    huankuai.style.color = "#9c9c9c"
                    return flag = false;
                    submit.disabled = true
                } else {
                    huankuai.style.backgroundColor = "#7AC23C"
                    huankuai.style.color = "#fff"
                    submit.disabled = false
                    return flag = true;
                }
            }
        }
    }
    shoujihao()
        // if (shoujihao()) {
        //     div_ulul[1].className = "action"
        //     biaodan[0].style.display = "none"
        //     biaodan[1].style.display = "block"
        // }

    function denglu() {
        var bt = document.getElementById("bt")
        var dengluming = document.dengluming
        var mima = dengluming.mima
        var xinmima = dengluming.xinmima
        var name = dengluming.mingzi
        var pwd2 = document.getElementById("pwd2")
        var pwd3 = document.getElementById("pwd3")
        var pwd4 = document.getElementById("pwd4")
        var flag = false
        dengluming.onsubmit = function() {
            // div_ulul[2].className = "action"
            // biaodan[1].style.display = "none"
            // biaodan[2].style.display = "block"
            return flag

        }
        bt.onclick = function() {
            if (mima.value == " " || mima.value.length > 12 || mima.value.length < 6) {
                pwd2.innerText = "密码不为空，且长度在4~12个字符！"
                flag = false;
                return false
            } else {
                pwd2.innerText = ""
                flag = true;
            }
            if (xinmima.value != mima.value) {
                pwd3.innerText = "两次输入的密码不一致！"
                flag = false;
                return false
            } else {
                pwd3.innerText = ""
                flag = true;
            }
            if (name.value == " " || !isNaN(name.value) || name.value.length < 4 || name.value.length > 10) {
                pwd4.innerText = "登录名不能为数字或空"
                flag = false;
                return false
            } else {
                pwd4.innerText = ""
                flag = true
            }
            // if (dengluming.onsubmit()) {

            // }
        }



    }
    denglu()


    function zhifu() {
        var myform = document.company;
        var mingzi = myform.mingzi
        var shenfen = myform.shenfrn
        var kahao = myform.kahao
        var mobile = document.getElementById("mobile")
        var haoma = myform.haoma
        var yanzhengma = myform.yanzhengma
        var sjyzm = document.getElementById("sjyzm")
        var btn = document.getElementById("btn")
        var pwd5 = document.getElementById("pwd5")
        var pwd6 = document.getElementById("pwd6")
        var pwd7 = document.getElementById("pwd7")
        var pwd8 = document.getElementById("pwd8")
        var flag = false
        var arr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
        mobile.onclick = function() {
            sjyzm.innerText = '';
            for (var i = 0; i < 4; i++) {
                var suiji = Math.floor(Math.random() * 36);
                sjyzm.innerText += arr[suiji];
                mobile.innerText = '重新获取';
            }
        }
        myform.onsubmit = function() {
            return flag
        }
        btn.onclick = function() {
            if (kahao.value == " " || isNaN(kahao.value) || kahao.value.length != 19) {
                pwd5.innerText = "卡号不能为空，并且不能少于19位"
                flag = false
                return false;
            } else {
                pwd5.innerText = ""
                flag = true
            }
            if (mingzi.value == " " || mingzi.value.length > 4 || mingzi.value.length < 2 || !isNaN(mingzi.value)) {
                pwd6.innerText = "请输入正确的名字"
                flag = false
                return false;
                // return false;
            } else {
                pwd6.innerText = ""
                flag = true
            }
            if (shenfen.value == " " || shenfen.value.length != 18) {
                pwd7.innerText = "身份证为18位"
                flag = false
                return false;
                // return false;
            } else {
                pwd7.innerText = ""
                flag = true
            }
            if (haoma.value == " " || haoma.value.length != 11 || haoma.value.charAt(0) != 1 || isNaN(haoma.value)) {
                pwd8.innerText = "请输入正确的手机号"
                flag = false
                return false;
                // return false;
            } else {
                pwd8.innerText = ""
                flag = true
            }
        }
    }
    zhifu()
    var div_ulul = document.querySelectorAll(".div-ulul li")
    var biaodan = document.querySelectorAll(".biaodan")
    var sub = document.querySelectorAll(".sub")
    console.log(sub)
    for (i = 0; i < sub.length; i++) {
        sub[i].indox = i
        sub[i].onclick = function() {
            div_ulul[this.indox + 1].className = "action"
            for (j = 0; j < biaodan.length; j++) {
                biaodan[j].style.display = "none"
            }
            biaodan[this.indox + 1].style.display = "block"
        }
    }
}