window.onload = function() {
    // 头部的隐藏部分
    var dis_1 = document.querySelectorAll(".dis")
    var dichu = document.querySelectorAll(".over")
    var guo = document.querySelectorAll(".dalu")
    for (i = 0; i < dichu.length; i++) {
        dichu[i].indox = i
        dichu[i].onmouseover = function() {
            guo[this.indox].style.backgroundColor = " #ffffff"
            dis_1[this.indox].style.display = "block"
        }
        dichu[i].onmouseout = function() {
            guo[this.indox].style.backgroundColor = ""
            dis_1[this.indox].style.display = "none"
        }
    }
    //搜索框上的三个样式 
    var baobei = document.querySelector(".baobei")
    console.log(baobei.children)
    var baobeia = baobei.children
    for (i = 0; i < baobeia.length; i++) {
        baobeia[i].indox = i
        baobeia[i].onmouseup = function() {
            for (var j = 0; j < baobeia.length; j++) {
                baobeia[j].className = "";
            }
            baobeia[this.indox].className = "bao"
        }
    }
    // 头部的右边二维码
    var ca = document.getElementsByClassName("ca")[0]
    var erwm = document.getElementsByClassName("erwm")[0]
    var tb = document.getElementsByClassName("tb")[0]
    ca.onclick = function() {
            tb.removeChild(erwm)
        }
        // 右拉宽
    var oli = document.querySelectorAll(".zuo_ul li")
    var odiv_zuo = document.querySelectorAll(".odiv_zuo")
    var odiv1 = document.querySelectorAll(".odiv1")
    for (j = 0; j < odiv1.length; j++) {
        odiv1[j].style.display = "none"
    }
    for (i = 0; i < oli.length; i++) {
        oli[i].indox = i
        oli[i].onmouseover = function() {
            odiv_zuo[this.indox].style.display = "block"
            odiv1[this.indox].style.display = "block"
        }
        oli[i].onmouseout = function() {
            odiv_zuo[this.indox].style.display = "none"
            odiv1[this.indox].style.display = "none"
        }

    }
    // 轮播图
    function slide() {
        var slide = document.querySelector(".slide");
        var picList = slide.querySelector(".picList");
        var dots = slide.querySelectorAll(".dots span");
        var btns = slide.querySelectorAll(".btns a");
        var index = 0;
        btns[1].onclick = function() {

            index++;

            if (index > 4) {
                index = 0;
            }
            picList.style.left = -520 * index + "px";
            for (var j = 0; j < dots.length; j++) {
                dots[j].className = "";
                dots[index].className = "on";

            }
        }
        btns[0].onclick = function() {
            index--;

            if (index < 0) {
                index = 4;
            }
            picList.style.left = -520 * index + "px";
            for (var j = 0; j < dots.length; j++) {
                dots[j].className = "";
                dots[index].className = "on";

            }
        };
        for (var i = 0; i < dots.length; i++) {
            dots[i].setAttribute("index", i);
            dots[i].onclick = function() {
                index = this.getAttribute("index");
                picList.style.left = -520 * index + "px";
                for (var j = 0; j < dots.length; j++) {
                    dots[j].className = "";
                    this.className = "on";

                }
            };
        }

        function go() {
            btns[1].onclick();
        }
        var timer = setInterval(go, 2000);
        slide.onmouseover = function() {
            clearInterval(timer);
            btns[0].style.display = "block"
            btns[1].style.display = "block"

        }
        slide.onmouseout = function() {
            timer = setInterval(go, 2000);
            btns[0].style.display = "none"
            btns[1].style.display = "none"
        }
    }
    slide();
    // 轮播图下面的小轮播图
    function tmlunbt() {
        var tmlunbt = document.querySelector(".tmlunbt");
        var opicList = tmlunbt.querySelector(".opicList");
        var obtns = tmlunbt.querySelectorAll(".obtns a");
        var shuzi = document.querySelector(".tianmao .tmtu .mtu .shuzi")
        var index = 0;
        obtns[1].onclick = function() {
            index++;

            if (index > 5) {
                index = 0;
            }
            opicList.style.left = -520 * index + "px";
            shuzi.innerText = index + 1
        }
        obtns[0].onclick = function() {
            index--;

            if (index < 0) {
                index = 5;
            }
            opicList.style.left = -520 * index + "px";
            shuzi.innerText = index + 1
        };

        function goes() {
            obtns[1].onclick();
        }
        var timer = setInterval(goes, 2000);
        tmlunbt.onmouseover = function() {
            obtns[1].style.display = "block"
            obtns[0].style.display = "block"
            clearInterval(timer);
        }
        tmlunbt.onmouseout = function() {
            timer = setInterval(goes, 2000);
            obtns[1].style.display = "none"
            obtns[0].style.display = "none"
        }
    }
    tmlunbt();
    // 右边的公共与规则
    var tablist = document.getElementsByClassName("tablist")[0]
    var tabli = tablist.children
    var listdivp = document.querySelectorAll(".listdiv p")
    for (i = 0; i < tabli.length; i++) {
        tabli[i].indox = i
        tabli[i].onmouseover = function() {
            for (h = 0; h < listdivp.length; h++) {
                listdivp[h].style.display = "none"
                tabli[h].style.borderBottom = ""
            }
            listdivp[this.indox].style.display = "block"
            tabli[this.indox].style.borderBottom = "2px solid #F40"

        }
    }
    // 交话费与旅游
    var chuchu2 = document.querySelectorAll(".chuchu2")
    var chuhchu = document.querySelectorAll(".chuhchu")
    var chuhchua = document.querySelectorAll(".chuhchu a")
    for (f = 0; f < chuchu2.length; f++) {
        chuchu2[f].indox = f
        chuchu2[f].onmouseover = function() {
            for (d = 0; d < chuhchu.length; d++) {
                chuhchu[d].style.display = "none"
            }
            chuchu2[this.indox].style.paddingTop = 2 + "px"
            chuhchu[this.indox].style.display = "block"
        }
    }
    for (e = 0; e < chuhchua.length; e++) {
        chuhchua[e].indox = e
        chuhchua[e].onclick = function() {
            for (p = 0; p < chuchu2.length; p++) {
                chuchu2[p].style.paddingTop = 0
            }
            chuhchu[this.indox].style.display = "none"
            return false
        }
    }
    // 每日好店推荐的效果部分
    var wanneng = document.getElementsByClassName("wanneng")
    var shiji = document.getElementsByClassName("shiji")
    for (i = 0; i < wanneng.length; i++) {
        wanneng[i].indox = i
        wanneng[i].onmouseover = function() {
            shiji[this.indox].style.color = "#FF555A"
        }
        wanneng[i].onmouseout = function() {
            shiji[this.indox].style.color = ""
        }
    }
    // 猜你喜欢隐藏部分
    var caini_div1 = document.querySelectorAll(".caini_div1")
    var caini_yc = document.querySelectorAll(".caini_yc")
    for (i = 0; i < caini_div1.length; i++) {
        caini_div1[i].indox = i
        caini_div1[i].onmouseover = function() {
            caini_yc[this.indox].style.display = "block"
        }
        caini_div1[i].onmouseout = function() {
            caini_yc[this.indox].style.display = "none"
        }
    }
    // 顶部的吸附
    var guding2 = document.getElementsByClassName("guding2")[0]
    var header = document.querySelector(".header")
    var taoxp = document.querySelector(".taoxp")
    var taobw = document.querySelector(".taobw")
    var guding = document.querySelector(".guding")
    document.onscroll = function() {
        var top = document.documentElement.scrollTop
        var t = header.offsetHeight + taoxp.offsetHeight + taobw.offsetHeight
        if (document.documentElement.scrollTop >= t) {
            guding2.style.display = "block"
        } else {
            guding2.style.display = "none";
        }
        if (top >= guding.offsetTop) {
            guding.style.position = "fixed"
            guding.style.top = 75 + "px"
        } else {
            guding.style.position = ""
            guding.style.top = ""
        }
    }

    function toubu() {
        var youhaoyun = document.querySelector(".youhaoyun")
        var father = youhaoyun.parentNode.parentNode
        var mga = document.getElementsByClassName("mga")[0]
        var mgaa = mga.children

        mgaa[0].onclick = function() {
            var top = document.documentElement.scrollTop;
            var youju = youhaoyun.offsetTop
            if (top < youju) {
                var timer = setInterval(function() {
                    top += 20;
                    if (top >= youju) {
                        clearInterval(timer);
                        return false
                    }
                    document.documentElement.scrollTop = top;
                }, 10)

            } else {
                var timer = setInterval(function() {
                    top -= 20;
                    if (top <= youju) {
                        clearInterval(timer);
                        return false
                    }
                    document.documentElement.scrollTop = top;
                }, 10);
            }


        }
        mgaa[1].onclick = function() {
            var top = document.documentElement.scrollTop;
            var youju = father.children[4].offsetTop
            if (top < youju) {
                var timer = setInterval(function() {
                    top += 20;
                    if (top >= youju) {
                        clearInterval(timer);
                        return false
                    }
                    document.documentElement.scrollTop = top;
                }, 10)

            } else {
                var timer = setInterval(function() {
                    top -= 20;
                    if (top <= youju) {
                        clearInterval(timer);
                        return false
                    }
                    document.documentElement.scrollTop = top;
                }, 10);
            }
        }
        mgaa[2].onclick = function() {
            var top = document.documentElement.scrollTop;
            var youju = father.children[6].offsetTop
            if (top < youju) {
                var timer = setInterval(function() {
                    top += 20;
                    if (top >= youju) {
                        clearInterval(timer);
                        return false
                    }
                    document.documentElement.scrollTop = top;
                }, 10)

            } else {
                var timer = setInterval(function() {
                    top -= 20;
                    if (top <= youju) {
                        clearInterval(timer);
                        return false
                    }
                    document.documentElement.scrollTop = top;
                }, 10);
            }
        }
        mgaa[3].onclick = function() {
            var top = document.documentElement.scrollTop;
            var youju = father.children[7].offsetTop
            if (top < youju) {
                var timer = setInterval(function() {
                    top += 20;
                    if (top >= youju) {
                        clearInterval(timer);
                        return false
                    }
                    document.documentElement.scrollTop = top;
                }, 10)

            } else {
                var timer = setInterval(function() {
                    top -= 20;
                    if (top <= youju) {
                        clearInterval(timer);
                        return false
                    }
                    document.documentElement.scrollTop = top;
                }, 10);
            }
        }
        mgaa[4].onclick = function() {
            var top = document.documentElement.scrollTop;
            var timer = setInterval(function() {
                top -= 30;
                document.documentElement.scrollTop = top;
                if (top <= 0) {
                    clearInterval(timer);
                }
            }, 10);
        }
    }
    toubu()
}