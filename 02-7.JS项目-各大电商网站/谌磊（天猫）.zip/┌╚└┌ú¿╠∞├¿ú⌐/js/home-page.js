// 导航栏吸附
function sade() {
	var sale = document.getElementsByClassName("sale")[0]
	var fixed = document.getElementsByClassName("fixed")[0]
	var fixeds = document.getElementsByClassName("fixed-b")[0]

	document.onscroll = function() {
		var to = sale.offsetTop
		var tose = document.documentElement.scrollTop || document.body.scrollTop;
		if (tose > to) {
			fixed.style.display = "block"
			fixeds.style.display = "block"
		} else {
			fixed.style.display = "none"
			fixeds.style.display = "none"
		}
	}
	window.onload = function() {
		var nav = document.getElementById("dao");
		var oli = document.querySelectorAll("#dao>li");
		var scroll = document.querySelectorAll(".free");

		for (var i = 0; i < oli.length; i++) {
			oli[i].index = i;
			oli[i].onclick = function() {
				var t1 = getPos(scroll[this.index]).top;
				var speed = 5;
				var t0 = document.documentElement.scrollTop;
				if (t1 > t0) {
					var timer = setInterval(function() {
						t0 += speed;
						if (t0 >= t1) {
							clearInterval(timer);
							return false;
						}
						document.documentElement.scrollTop = t0 - nav.offsetHeight - 10;
					}, 5);
				} else {
					var timer = setInterval(function() {
						t0 -= speed;
						if (t0 <= t1) {
							clearInterval(timer);
							return false;
						}
						document.documentElement.scrollTop = t0 - nav.offsetHeight - 10;
					}, 5);
				}
			}
		}

		function getPos(ele) {
			// body... 
			// 初始值
			var l = 0;
			var t = 400;
			while (ele.offsetParent) {
				l += ele.offsetLeft + ele.offsetParent.clientLeft;
				t += ele.offsetTop + ele.offsetParent.clientTop;
				ele = ele.offsetParent;
				console.log(ele); //father,grand,body,null
			}
			// 等上面的循环体结束后才会输出{}
			return {
				'left': l,
				'top': t
			};
		}
	};
}
sade()

// 图标
function call() {
	var myimg = document.getElementsByClassName("my-img");
	var block = document.getElementsByClassName("block");
	for (var i = 0; i < myimg.length; i++) {
		myimg[i].index = i
		for (var j = 0; j < block.length; j++) {
			myimg[i].onmouseover = function() {
				block[this.index].style.display = "block";
			}
			myimg[i].onmouseout = function() {
				block[this.index].style.display = "none";
			}
		}
	}
}
call()

// 轮播
function dan() {
	var slide = document.querySelector(".slide");
	var li = slide.querySelectorAll(".picList li");
	var btnss = document.querySelector(".btns");
	var btns = slide.querySelectorAll(".btns a");
	var dots = slide.querySelectorAll(".dots span");
	var index = 0;

	function fun() {
		for (var j = 0; j < dots.length; j++) {
			dots[j].className = "";
			dots[index].className = "on";

		}
	}
	// 设置左边的按钮
	btns[0].onclick = function() {
		for (var j = 0; j < li.length; j++) {
			li[j].style.opacity = 0
		}
		index++
		if (index > 4) {
			index = 0
		}
		li[index].style.transition = "all 0.5s linear"
		li[index].style.opacity = 1;
		fun()
	}
	// 设置右边的按钮
	btns[1].onclick = function() {
		for (var j = 0; j < li.length; j++) {
			li[j].style.opacity = 0
		}
		index--
		if (index < 0) {
			index = 4
		}
		li[index].style.transition = "all 0.5s linear"
		li[index].style.opacity = 1;
		fun()
	}
	// 给小圆点绑定事件
	for (var i = 0; i < dots.length; i++) {
		dots[i].setAttribute("index", i);
		dots[i].onclick = function() {
			index = this.getAttribute("index");
			for (var j = 0; j < li.length; j++) {
				li[j].style.opacity = 0
			}
			li[index].style.transition = "all 0.5s linear"
			li[index].style.opacity = 1;
			fun()
		};
	}
	// 通过定时器实现自动轮播
	function go() {
		btns[0].onclick();
	}
	var timer = setInterval(go, 3000);
	// 鼠标移入到轮播图区域，暂停播放，离开再恢复播放
	slide.onmouseover = function() {
		btnss.style.display = "block";
		clearInterval(timer);

	}
	// 鼠标离开时恢复播放
	slide.onmouseout = function() {
		btnss.style.display = "none";
		timer = setInterval(go, 1500);
	}
}
dan()

function EDG() {
	var inlas = document.getElementsByClassName("inlas");
	var clslds = document.getElementsByClassName("clslds");
	for (var i = 0; i < inlas.length; i++) {
		inlas[i].index = i
		for (var j = 0; j < clslds.length; j++) {
			inlas[i].onmouseover = function() {
				clslds[this.index].style.display = "block";
			}
			inlas[i].onmouseout = function() {
				clslds[this.index].style.display = "none";
			}
		}
	}
}
EDG()

function LGD() {
	var dli = document.getElementsByClassName("dli");
	var clsld = document.getElementsByClassName("clsld");
	for (var i = 0; i < dli.length; i++) {
		dli[i].index = i
		for (var j = 0; j < clsld.length; j++) {
			dli[i].onmouseover = function() {
				clsld[this.index].style.display = "block";
			}
			dli[i].onmouseout = function() {
				clsld[this.index].style.display = "none";
			}
		}
	}
}
LGD()

function fun() {
	var leach = document.getElementsByClassName("nav_left");
	var lock = document.getElementsByClassName("sanji");
	for (var i = 0; i < leach.length; i++) {

		leach[i].index = i
		for (var j = 0; j < lock.length; j++) {
			leach[i].onmouseover = function() {
				lock[this.index].style.display = "block";
			}
			leach[i].onmouseout = function() {
				lock[this.index].style.display = "none";
			}
		}

	}
}
fun()

function FPX() {
	var ding = document.getElementById("ding");
	ding.onclick = function() {
		// var speed=5;
		// 读：读取当前滚动条的位置信息
		var top = document.documentElement.scrollTop; //100
		var timer = setInterval(function() {
			// speed+
			top -= 10;
			console.log(1)
			// scrollTop是可读写的！！
			// 写，改变滚动条的位置
			document.documentElement.scrollTop = top;
			if (top <= 0) {
				clearInterval(timer);
			}
		}, 5);
	}
}
FPX()
