function FNC() {
	var fi1 = document.getElementById("fi1");
	var fi2 = document.getElementById("fi2");
	var fi3 = document.getElementById("fi3");
	var fi4 = document.getElementById("fi4");
	var yc = document.getElementsByClassName("head-1")[0];
	var button = document.getElementsByClassName("button")[0];
	fi1.className = "on"
	var xinxi = document.getElementsByClassName("xinxi")[0];
	var yonghu = document.getElementsByClassName("yonghu")[0];
	var fukuan = document.getElementsByClassName("fukuan")[0];
	button.onclick = function() {
		yc.style.display = "none";
		if (yc.style.display = "none") {
			xinxi.style.display = "block"
		}
		var phonenum = document.getElementsByName("phonenum")[0];
		var btn = document.getElementsByClassName("btn")[0];
		btn.onclick = function() {
			var ss = /1[345789][0-9]{9}$/
			if (ss.test(phonenum.value)) {
				alert("正确")
				xinxi.style.display = "none"
				yonghu.style.display = "block"
				fi1.className = ""
				fi2.className = "on"
			} else {
				alert("请输入正确的手机号码")
			}
		}
		var btnn = document.getElementsByClassName("btnn")[0];
		btnn.onclick = function() {
			var username = document.getElementsByName("username")[0];
			var password = document.getElementsByName("password")[0];
			var email = document.getElementsByName("email")[0];
			var name = /^[a-z][0-9a-z]{5,14}/ig
			username.onblur = function() {
				if (name.test(username.value)) {
					console.log("正确")
				} else {
					alert("用户名格式错误")
				}
			}
			//密码6~10位可以为字母和数字
			var pass = /[0-9a-z]{6,10}/ig
			password.onblur = function() {
				if (pass.test(password.value)) {
					console.log("正确")
				} else {
					alert("密码格式错误")
				}
			}
			//判断邮箱是否合法（比如123@qq.com）
			var ema = /\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}/ig
			email.onblur = function() {
				if (ema.test(email.value)) {
					console.log("正确")
				} else {
					alert("邮箱格式错误")
				}
			}
			if (name.test(username.value) && pass.test(password.value) && ema.test(email.value)) {
				yonghu.style.display = "none"
				fukuan.style.display = "block"
				fi2.className = ""
				fi3.className = "on"
			} else {
				alert("请完善您的信息")
			}
		}
		var bat = document.getElementsByClassName("bat")[0];
		var hui=document.getElementsByClassName("hui")[0];
		var fukuan=document.getElementsByClassName("fukuan")[0]
		bat.onclick = function() {
			if (fukuan.style.display = "none") {
				hui.style.display = "block"
				fi3.className = ""
				fi4.className = "on"
			}
		}
		
	}

}
FNC()
