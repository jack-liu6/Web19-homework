function IG() {
	var land2 = document.getElementsByClassName("land2")[0];
	var land6 = document.getElementsByClassName("land6")[0];
	land2.onmouseover = function() {
		land6.style.display = "block"
	}
	land2.onmouseout = function() {
		land6.style.display = "none"
	}
	var land13 = document.getElementsByClassName("land13")[0];
	var land14 = document.getElementsByClassName("land14")[0];
	land13.onmouseover = function() {
		land14.style.display = "block"
	}
	land13.onmouseout = function() {
		land14.style.display = "none"
	}
}
IG()

function dos() {
	var dli = document.getElementsByClassName("dli");
	var clsld = document.getElementsByClassName("clsld");
	for (var i = 0; i < dli.length; i++) {
		dli[i].index = i
		for (var j = 0; j < clsld.length; j++) {
			dli[i].onmouseover = function() {
				clsld[this.index].style.display = "block";
			}
			dli[i].onmouseout = function() {
				clsld[this.index].style.display = "none";
			}
		}
	}
}
dos()

function lee() {
	var inlas = document.getElementsByClassName("inlas");
	var clslds = document.getElementsByClassName("clslds");
	for (var i = 0; i < inlas.length; i++) {
		inlas[i].index = i
		for (var j = 0; j < clslds.length; j++) {
			inlas[i].onmouseover = function() {
				clslds[this.index].style.display = "block";
			}
			inlas[i].onmouseout = function() {
				clslds[this.index].style.display = "none";
			}
		}
	}
}
lee()

function dis() {
	var acc = document.getElementsByClassName("acc")[0]
	var detracts = document.getElementsByClassName("desymbol")[0]
	var adds = document.getElementsByClassName("adsymbol")[0]
	var num = 1;
	adds.onclick = function() {
		num += 1;
		acc.innerHTML = num;
	}
	detracts.onclick = function() {
		num -= 1;
		if (num < 1) {
			num = 1;
		}
		acc.innerHTML = num;
	}

}
dis()
