// 头部JS
var hunan=document.querySelector('.hunan');
var items=document.querySelectorAll('.items');
for(var i=0;i<items.length;i++){
	    
	items[i].onclick=function(e){
		
		e.preventDefault();
		hunan.innerText=this.children[0].innerText;
		
		for(var j=0;j<items.length;j++){
			items[j].id='';
		}
		this.id='red';
		
	}
	
}

var searchipt=document.getElementById('searchipt');
searchipt.onfocus=function(){
	searchipt.value='';
};
searchipt.onblur=function(){
	searchipt.value='请输入商品';
};

var searchpic=document.querySelector('.searchpic');


searchpic.onmouseover=function(){
	this.children[0].src='image/jd/kaobei.png';
	
};
searchpic.onmouseout=function(){
	this.children[0].src='image/jd/pp.png'
}

//end

   // 鼠标移入切换放大镜图
   var zoom1=document.querySelector('.sdiv>img');
   var zoom2=document.querySelector('.bdiv>img')
   var zoom4=document.getElementById('zoom4');
   var zoom5=document.getElementById('zoom5');
   zoom4.onmouseover=function(){
	   zoom1.src="image/detail/zoom1.jpg";
	   zoom2.src="image/detail/zoom2.jpg";
   }
   zoom5.onmouseover=function(){
   	   zoom1.src="image/detail/zoom3.jpg";
	   zoom2.src="image/detail/zoom7.jpg";
   }


//放大镜

//当鼠标移入到缩略图时，才显示滑块和右边大图
        //缩略图
        var sdiv=document.querySelector(".sdiv");
        // 滑块
        var oSpan=document.querySelector("#oSpan");
        // 大图盒子
        var bdiv=document.querySelector(".bdiv");
        // 大图图片
        var bimg=document.querySelector(".bdiv>img");

        // 让滑块在缩略图盒子中跟随鼠标移动
        sdiv.onmousemove=function(e){
            // 滑块的可移动范围：0-150px
            // l表示滑块的水平移动距离
            var l=e.clientX-getPos(this).left-oSpan.offsetWidth/2;
            // t
            var t=e.clientY-getPos(this).top+100;

            console.log(l+","+t)
            // 150
            // 滑块的可移动距离
            var L=sdiv.clientWidth-oSpan.offsetWidth;
            var T=sdiv.clientHeight-oSpan.offsetHeight;
            // 边界判断
            // 最左边时
            if(l<0){
                l=0;
            }
            // 最右边时
            if(l>L){
                l=L;
            }
            // 最下边时
            if(t<0){
                t=0;
            }
            if(t>T){
                t=T;
            }
            // l
            oSpan.style.left=l+"px";
            oSpan.style.top=t+"px";

            // 找比例

            // L/l=比例
            // 相当于是找当滑块在左边移动一个像素时，右边要移动多少个像素的问题
            // bx表示水平方向的比例
            var bx=(bimg.clientWidth-bdiv.clientWidth)/(sdiv.clientWidth-oSpan.offsetWidth);
            var by=(bimg.clientHeight-bdiv.clientHeight)/(sdiv.clientHeight-oSpan.offsetHeight);
            console.log(bx+","+by);
 
            // 找到比例后，要将l*bx才是大图要移动的距离

            bimg.style.left=-l*bx+"px";
            bimg.style.top=-t*by+"px";

        }
        // 鼠标移入到缩略图时，显示大图和滑块
        sdiv.onmouseover=function(){
            oSpan.style.display=bdiv.style.display="block";
        };
         // 鼠标离开到缩略图时，显示大图和滑块
        sdiv.onmouseout=function(){
            oSpan.style.display="none";
            bdiv.style.display="none";
        };

        // 求绝对距离的函数
        function getPos (ele) {
          // body... 
          // 初始值
          var l=0;//21,21,8
          var t=0;
          // l+=ele.offsetLeft;
          // l+=ele.offsetParent.offsetLeft
          while (ele.offsetParent) {
            // statement
            l+=ele.offsetLeft+ele.offsetParent.clientLeft;
            t+=ele.offsetTop+ele.offsetParent.clientTop;
            // 将元素替换为元素的定位父级（迭代）
            ele=ele.offsetParent;
            // console.log(ele);//father,grand,body,null
          }
          // 等上面的循环体结束后才会输出{}
          return {
              'left':l,
              'top':t
          };

        }
		
		
		//倒计时
		
		//通过定时器每隔1s执行一次
		setInterval(function(){
		    //Date不添加参数，则表示现在的时间
		    var d=new Date();
		    // Date添加一个时间日期参数，则表示未来或过去的时间
		    var past=new Date('2020-6-7 08:53:03');//过去的时间戳
		    var future=new Date('2020-8-20 00:00:00');
		
		    // 将未来的时间减去现在此时此刻的时间就是这两个时间的时间差（返回的是毫秒数）
		    var cha=future-d;
		    console.log(cha);//2678308436
		
		    // 如果要转成秒数，则需要除以1000，也就是8月7日距离现在还有2678308秒
		    // 1s=1000ms
		    var chas=parseInt(cha/1000);//2678308
		    // 接下来就需要将这个秒数换算成 x天x时x分x秒
		
		    var day=parseInt(chas/3600/24);//得到多少天了
		    // 土方法：chas-day*86400=
		
		    console.log(day);//30
		
		    var hours=parseInt(chas/3600%24);//小时
		    console.log(hours);//23
		
		    // 
		    var min=parseInt(chas%3600/60);//分钟
		    console.log(min);//21
		
		    var sec=chas%60;
		    console.log(sec);//11
			
			if(hours<10){
					  hours='0'+hours;
			}else{
					  hours=hours;
			}
			  
			// 
			var min=parseInt(chas%3600/60);//分钟
			if(min<10){
					  min='0'+min;
			}else{
					  min=min;
			}
			  
			var sec=chas%60;
			if(sec<10){
					  sec='0'+sec;
			}else{
					  sec=sec;
			}
		
		    // console.log("距离还剩："+day+"天"+hours+"时"+min+"分"+sec+"秒");
		    // document.getElementById("box").innerText="距离2020年8月7日还剩："+day+"天"+hours+"时"+min+"分"+sec+"秒"
			document.querySelector('.day').innerText=day;
			document.querySelector('.hours').innerText=hours;
			document.querySelector('.min').innerText=min;
			document.querySelector('.sec').innerText=sec;
		}, 1000);
		


// 点击选框颜色

var yanse=document.querySelectorAll('.yanse');
var banben=document.querySelectorAll('.banben1');
var fangshi=document.querySelectorAll('.fangshi1');
var baozhang=document.querySelectorAll('.baozhang1');
var baitiao=document.querySelectorAll('.baitiao1');
changeColor(yanse);
changeColor(banben);
changeColor(fangshi);
changeColor(baozhang);
changeColor(baitiao);

function changeColor(obj){
for(var i=0;i<obj.length;i++){
	obj[i].onclick=function(e){
		e.preventDefault();
		
		for(var j=0;j<obj.length;j++){
			obj[j].style.borderColor='#'+'ddd';
		}
		this.style.borderColor='red';
	}
	
}
}

//购物车数量
var caript=document.getElementById('caript');
var carjia=document.querySelector('.carjia');
var carjian=document.querySelector('.carjian');
carjia.onclick=function(e){
	e.preventDefault();
	caript.value=parseInt(caript.value)+1;
	fenqi[0].innerText=parseInt(fenqi[0].innerText)*parseInt(caript.value);
}
carjian.onclick=function(e){
	e.preventDefault();
	caript.value=parseInt(caript.value)-1;
	fenqi[0].innerText=parseInt(fenqi[0].innerText)*parseInt(caript.value);
	if(parseInt(caript.value)<0){
		caript.value=0;
	}
}

var fenqi=document.querySelectorAll('.baitiao1>span');


// 人气 tab切换
 function tab(tabBt,tabBd,eventtype){
	  var but=document.getElementById(tabBt);
	  var bd=document.getElementById(tabBd);
	  var butList=but.children;  //所有按钮
	  var bdList=bd.children;    //所有要切换的页面
	  for(var i=0;i<butList.length;i++){
		  butList[i].index=i;
		  butList[i][eventtype]=function(e){
			  e.preventDefault();
			  for(var j=0;j<bdList.length;j++){
				  if(j==this.index){
					  bdList[this.index].style.display='block';
					  this.className='red1';//要显示的样式
					  this.id='white';
				  }else{
					  bdList[j].style.display='none';
					  butList[j].className='';
					  butList[j].id='';
				  }
			  }
		  }
	  }
	  
  }
  
  tab("tab1","tbody1","onclick");
  tab("rxul","rxtab","onclick");
  tab("jieshaotab","jieshaotabd","onclick");
  
  // 多选框
  var rqipt=document.getElementsByName('rqipt');
  var pj=document.getElementById('pj');
  var jg=document.getElementById('jg');
  for(var i=0;i<rqipt.length;i++){
	  rqipt[i].onclick=function(){
		  if(this.checked==true){
			  pj.innerText=parseInt(pj.innerText)+1;
			  jg.innerText=parseInt(jg.innerText)+100+'.00';
		  }else if(this.checked==false){
			  pj.innerText=parseInt(pj.innerText)-1;
			  jg.innerText=parseInt(jg.innerText)-100+'.00';
		  }
	  }
  }
  
  
  //手风琴
  
  var flag=true;
  var container=document.querySelector(".container");
  var title=document.querySelectorAll(".title");
  var content=document.querySelectorAll(".content");
  // console.log(title);
  // 第一个for循环是给所有的title（标题）绑定事件
  for(var i=0;i<title.length;i++){
  	// 给每一个title添加自定义属性，这样方便定位当前点击的是哪个title，从而控制对应的面板元素
  	title[i].index=i;
  	title[i].onclick=function(){
  		// for,先将所有面板状态设为隐藏，再将当前的显示
  		
  		// 将当前面板设置为显示状态
  		if(flag){
  		content[this.index].style.display="block";
		title[this.index].firstElementChild.className='titlejian';
  		flag=false;
  		}else{
  			content[this.index].style.display="none";
			title[this.index].firstElementChild.className='titlejia';
  			flag=true;
  		}
  
  
  	};
  }
  
  
  // 评价框点击变色
  var pjk=document.querySelectorAll('.pjk');
  for(var i=0;i<pjk.length;i++){
	  pjk[i].onclick=function(){
		  for(var j=0;j<pjk.length;j++){
		  		 pjk[j].style.borderColor='rgb(244,244,244)';
				 pjk[j].style.color='#'+'666';
		  }
		  this.style.borderColor='red';
		  this.style.color='red';
	  }
  }
  
  
  var iwant=document.querySelector('.iwant');
  var pop_bg=document.getElementById('pop_bg');
  var pop_div=document.getElementById('pop_div');
  var pop_btn1=document.getElementById('pop_btn1');
  var pop_btn=document.getElementById('pop_btn');
  var em1=document.getElementById('em1');
  var em2=document.getElementById('em2');
  iwant.onclick=function(){
	  pop_bg.style.display='block';
	  pop_div.style.display='block';
	  
  }
  
  pop_btn.onclick=function(){
	  pop_bg.style.display='none';
	  pop_div.style.display='none';
  }
  
  
	  var zhanghao=document.getElementById('zhanghao');
	  var mima=document.getElementById('mima');
	  var  reg1=/^[a-zA-Z]\w{5,14}$/;
	  zhanghao.onblur=function(){
	  if(!reg1.test(zhanghao.value)){
		  em1.innerText='×';
		  em1.className='red';
	  }else{
		  em1.innerText='√';
		  em1.className='green';
	  }
  };
  
    mima.onblur=function(){
    	  if(mima.value.length==0){
    		  em2.innerText='不能为空';
    		  em2.className='red';
    	  }else{
    		  em2.innerText='√';
    		  em2.className='green';
    	  }
    };
  
  