var pop_bt=document.querySelector('.pop_bt');
var pop_bg=document.getElementById('pop_bg');
var pop_div=document.getElementById('pop_div');
window.onload=sy();
function sy(){
	pop_bg.style.display='block';
	pop_div.style.display='block';
	pop_bt.onclick=function(){
		pop_bg.style.display='none';
		pop_div.style.display='none';
	}
}


var phonenum1=document.querySelector('.phonenum1');
var flag=true;
var numnav=document.querySelector('.numnav');
var xia=document.getElementById('xia');
var diqu=document.querySelectorAll('.diqu');
var quhao=document.querySelectorAll('quhao');
var text=phonenum1.firstElementChild;

phonenum1.onclick=function(){
	if(flag){
		numnav.style.display='block';
		xia.className='shang';
		
		flag=false;
	}else{
		numnav.style.display='none';
		xia.className='xia';
		
		flag=true;
	}
}

for(var i=0;i<diqu.length;i++){
	
	diqu[i].onclick=function(){
		text.innerText=this.innerText;
		
	}
}

// 账号栏
var phoneipt=document.getElementById('phoneipt');
var phoneipt1=document.getElementById('phoneipt1');
var phoneipt2=document.getElementById('phoneipt2');
var cuo=document.getElementById('cuo');
var em1value=document.querySelector('.em1value');
var em2value2=document.querySelector('.em2value2');
var em3value3=document.querySelector('.em3value3');
var yz=document.querySelector('.yz');

phoneipt.onfocus=function(){
	phoneipt.value='';
	phoneipt.style.color='#'+'666';
	cuo.className='';
	em1value.innerText='';
}
phoneipt.onblur=function(){
	var phonereg=/^1[3-9][0-9]{9}$/;
	var syy=0;
	if(phonereg.test(this.value)){
		cuo.className='dui';
		em1value.innerText='格式正确';
		em1value.className='em1value green';
		syy=1;
		return syy;
	}else{
		cuo.className='cuo';
		em1value.className='em1value';
		em1value.innerText='格式错误';
	}
	phoneipt.value='建议使用常用手机号';
	phoneipt.style.color='#'+'ddd';
	
}
   // 第二个页面验证
   //账号
   phoneipt1.onfocus=function(){
	   phoneipt1.value='';
	   phoneipt1.style.color='#'+'666';
	   em2value2.innerText='';
   }
   
   phoneipt1.onblur=function(){
	   var haoreg=/^[A-z][0-9A-z_]{5,14}$/g;
	   if(haoreg.test(this.value)){
		   em2value2.className='em2value2 green';
		   em2value2.innerText='格式正确';
	   }else{
		   em2value2.className='em2value2';
		   em2value2.innerText='格式错误';
	   }
	   phoneipt1.value='请输入账号';
	   phoneipt1.style.color='#'+'ddd';
   }
   //密码
   phoneipt2.onfocus=function(){
   	   phoneipt2.value='';
   	   phoneipt2.style.color='#'+'666';
   	   em3value3.innerText='';
   }
   
   phoneipt2.onblur=function(){
   	   var haoreg=/^[0-9a-z]{6,10}$/ig;
   	   if(haoreg.test(this.value)){
   		   em3value3.className='em3value3 green';
   		   em3value3.innerText='密码正确';
   	   }else{
   		   em3value3.className='em3value3';
   		   em3value3.innerText='密码错误';
   	   }
   	   phoneipt2.value='请输入密码';
   	   phoneipt2.style.color='#'+'ddd';
   }


	yz.onclick=function(){
		if(flag){
			yzk.style.display='block';
			
			flag=false;
		}else{
			yzk.style.display='none';
			flag=true;
		}
	}

//拖拽
var yzk=document.querySelector('.yzk');
var ball=document.getElementById('ball');
var ball1=document.getElementById('ball1');
var yz1=document.querySelector('.yz1');
ball.onmousedown=function(e){
	var disx=e.clientX-ball.offsetLeft;
	ball.onmousemove=function(e){
		var xx=e.clientX-disx
		console.log(xx)
		if(xx>340){
			xx=340;
		}
		if(xx<20){
			xx=20;
		}
		ball.style.left=xx+"px";
		ball1.style.left=ball.style.left;
		if(xx>=130&&xx<=135){
			yz1.innerText='验证成功^_^ 点击关闭';
		}else{
			yz1.innerText='';
		} //验证成功后显示
	}
	ball.onmouseup=function(){
	    // 鼠标松开时，要清空鼠标移动事件，防止盒子跟随鼠标移动停不下来
	    ball.onmousemove=null;
	}
}

//拖拽验证成功后关闭
yz1.onclick=function(){
	yzk.style.display='none';
}

//固定栏
var fixyou=document.querySelector('.fixyou');
fixyou.onmouseover=function(){
	this.children[0].className='fixsp2';
}
fixyou.onmouseout=function(){
	this.children[0].className='fixsp1';
}

// 下一步按钮事件
var nextbtn=document.querySelector('.nextbtn');
var zhishi1=document.getElementById('zhishi1');
var zhishi2=document.getElementById('zhishi2');
var index2=document.getElementById('index2');
var index3=document.getElementById('index3');
var main=document.querySelectorAll('.main');

nextbtn.onclick=function(){
	if(flag){
		zhishi1.className='zhishi1_1';
		index2.style.color='#'+'3b4';
		index2.style.borderColor='#'+'3b4';
		document.querySelector('.step2p').style.color='#'+'3b4';
		main[0].style.display='none';
		main[1].style.display='block';
		main[2].style.display='none';
		flag=false;
	}else{
		zhishi2.className='zhishi2_2';
		index3.style.color='#'+'3b4';
		index3.style.borderColor='#'+'3b4';
		document.querySelector('.step3p').style.color='#'+'3b4';
		main[0].style.display='none';
		main[1].style.display='none';
		main[2].style.display='block';
		nextbtn.innerText='项目完成 收工';
		flag=true;
	}
}

