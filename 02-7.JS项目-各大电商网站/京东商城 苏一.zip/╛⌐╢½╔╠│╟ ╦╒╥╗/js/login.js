var er=document.querySelector('.er');
var yctu=document.querySelector('.yctu');
er.onmouseover=function(){
	
	yctu.style.display='block';
	
};
er.onmouseout=function(){
	
	yctu.style.display='none';
	
}


//tab切换

function tab(tabBt,tabBd,eventtype){
	  var but=document.getElementById(tabBt);
	  var bd=document.getElementById(tabBd);
	  var butList=but.children;  //所有按钮
	  var bdList=bd.children;    //所有要切换的页面
	  for(var i=0;i<butList.length;i++){
		  butList[i].index=i;
		  butList[i][eventtype]=function(e){
			  e.preventDefault();
			  for(var j=0;j<bdList.length;j++){
				  if(j==this.index){
					  bdList[this.index].style.display='block';
					  this.children[0].className='bt1a cu';//按钮要显示的样式
				  }else{
					  bdList[j].style.display='none';
					  butList[j].children[0].className='bt1a';
				  }
			  }
		  }
	  }
	  
  }
  
  tab("loginbt","logintd","onclick");
  
  var ipt=document.getElementById('ipt');
  var cha=document.getElementById('cha');
  var iptu=document.getElementById('iptu');
  var psdtu=document.getElementById('psdtu');
  var psd=document.getElementById('psd');
  
  var reg2=/^[0-9a-z]{6,10}$/ig;
  ipt.onfocus=function(){
	  ipt.value='';
	  cha.className='cha';
	  iptu.className='sp6';
	 
  }
  
  ipt.onblur=function(){
	  var reg1=/^[A-z][0-9A-z_]{5,14}$/g;
	  if(reg1.test(ipt.value)){
		  ipt.style.borderColor='forestgreen';
	  }else{
		  ipt.style.borderColor='red';
	  }
	  
	  
	  cha.className='';
	  iptu.className='sp4';
	  
  }
  psd.onfocus=function(){
	   psdtu.className='sp7';
  }
  psd.onblur=function(){
	  var reg2=/^[0-9a-z]{6,10}$/ig;
	  if(reg2.test(psd.value)){
		   psd.style.borderColor='forestgreen';
	  }else{
		  psd.style.borderColor='red';
	  }
	   psdtu.className='sp5';
  }
  
  cha.onclick=function(){
	  ipt.value='邮箱/用户名/登录手机';
  }
  cha.onmouseover=function(){
	  cha.className='cha1';
  }
  cha.onmouseout=function(){
	  cha.className='cha';
  }