var hunan=document.querySelector('.hunan');
var items=document.querySelectorAll('.items');
for(var i=0;i<items.length;i++){
	    
	items[i].onclick=function(e){
		
		e.preventDefault();
		hunan.innerText=this.children[0].innerText;
		
		for(var j=0;j<items.length;j++){
			items[j].id='';
		}
		this.id='red';
		
	}
	
}

var searchipt=document.getElementById('searchipt');
searchipt.onfocus=function(){
	searchipt.style.color='lightgray';
};
searchipt.onblur=function(){
	searchipt.style.color='#'+'5E5E5E';
};

var searchpic=document.querySelector('.searchpic');


searchpic.onmouseover=function(){
	this.children[0].src='image/jd/kaobei.png';
	
};
searchpic.onmouseout=function(){
	this.children[0].src='image/jd/pp.png'
}

function slide(){
	var slide=document.querySelector('.slide');
	var piclist=document.querySelector('.piclist');
	var pic=document.querySelectorAll('.pic');
	var btns=slide.querySelectorAll('.btns button');
	var dots=slide.querySelectorAll('.listpoint li');
	var next=document.querySelector('.next');
	var prev=document.querySelector('.prev');
	var index=0;
	next.onclick=function(){
		index++;
		if(index>2){
			index=0;
		}
		for(var i=0;i<pic.length;i++){
			pic[i].className='pic';
			dots[i].className='point';
		}
		pic[index].className='pic active';
		dots[index].className='point active1';
	}
	prev.onclick=function(){
		index--;
		if(index<0){
			index=2;
		}
		for(var i=0;i<pic.length;i++){
			pic[i].className='pic';
			dots[i].className='point';
		}
		pic[index].className='pic active';
		dots[index].className='point active1';
	}
	for (var i=0;i<dots.length;i++) {
		dots[i].setAttribute('index',i);
		dots[i].onclick=function(){
			index=this.getAttribute('index');
			
			for (var i=0;i<pic.length;i++) {
						pic[i].className='pic';
						
					}
			pic[index].className='pic active';
			for (var j=0;j<dots.length;j++) {
				dots[j].className='point';
				this.className='point active1';
			}
		}
	}
	function go(){
		next.onclick();
	}
	var timer=setInterval(go,2000)
	
	slide.onmouseover=function(){
						clearInterval(timer);
					};
	slide.onmouseout=function(){
						timer=setInterval(go,2000);
					}
	
}
slide();


var prev1=document.querySelector('.prev1');
var next1=document.querySelector('.next1');
var sy1=document.getElementById('sy1');
var sy2=document.getElementById('sy2');
var sy3=document.getElementById('sy3');
var flag=true;
next1.onclick=prev1.onclick=function(){
	if(flag){
		sy1.src="image/111/tu2.png";
		sy2.src="image/111/tu5.png";
		sy3.src="image/111/tu6.png";
		flag=false;
	}else{
		sy1.src="image/111/tu1.png";
		sy2.src="image/111/tu3.png";
		sy3.src="image/111/tu2.png";
		flag=true;
	}
};

function qie(){
	if(flag){
		sy1.src="image/111/tu2.png";
		sy2.src="image/111/tu5.png";
		sy3.src="image/111/tu6.png";
		flag=false;
	}else{
		sy1.src="image/111/tu1.png";
		sy2.src="image/111/tu3.png";
		sy3.src="image/111/tu2.png";
		flag=true;
	}
}

var timer=setInterval(qie,2000);

var slide3=document.querySelector('.slide3');
slide3.onmouseover=function(){
	clearInterval(timer);
};
slide3.onmouseout=function(){
	timer=setInterval(qie,2000);
}

var hfk=document.querySelector('.hfk');
var hf=document.getElementById('hf');
var cha=document.getElementById('cha');
var hfipt=document.getElementById('hfipt');
var ecode=document.getElementById('ecode');
var reg=/^1[3-9][0-9]{9}$/;
var hfsel=document.getElementById("hfsel");
var qian=document.getElementById('qian');
var kuaichong=document.querySelector('.kuaichong');
console.log(qian)
hf.onmouseover=function(){
	hfk.style.display='block';
}
cha.onclick=function(){
	hfk.style.display='none';
}

hfipt.onfocus=function(){
	hfipt.value='';
}
hfipt.onblur=function(){
	if(reg.test(this.value)){
		ecode.className='green font11';
		ecode.innerText='正确';
	}else{
		ecode.className='red font11';
		ecode.innerText='错误';
		hfipt.value='请输入手机号';
	}
	
}

hfsel.onchange=function(){
	if(hfsel.value==1){
		qian.innerText='￥'+"48";
	}
	if(hfsel.value==2){
		qian.innerText='￥'+"58";
	}
	if(hfsel.value==3){
		qian.innerText='￥'+"68";
	}
	if(hfsel.value==4){
		qian.innerText='￥'+"78";
	}
}

var taocan=document.querySelectorAll('.taocan a');
console.log(taocan)



function tab(tabBt,tabBd,eventtype){
	  var but=document.getElementById(tabBt);
	  var bd=document.getElementById(tabBd);
	  var butList=but.children;  //所有按钮
	  var bdList=bd.children;    //所有要切换的页面
	  for(var i=0;i<butList.length;i++){
		  butList[i].index=i;
		  butList[i][eventtype]=function(e){
			  e.preventDefault();
			  for(var j=0;j<bdList.length;j++){
				  if(j==this.index){
					  bdList[this.index].style.display='block';
					  this.className='red font11';//要显示的样式
				  }else{
					  bdList[j].style.display='none';
					  butList[j].className='font11';
				  }
			  }
		  }
	  }
	  
  }
  
  tab("tab1","tbody1","onmouseover");
  
  
  setInterval(function(){
      //Date不添加参数，则表示现在的时间
      var d=new Date();
      // Date添加一个时间日期参数，则表示未来或过去的时间
      var past=new Date('2020-6-7 08:53:03');//过去的时间戳
      var future=new Date('2020-8-20 00:00:00');
  
      // 将未来的时间减去现在此时此刻的时间就是这两个时间的时间差（返回的是毫秒数）
      var cha=future-d;
      
  
      // 如果要转成秒数，则需要除以1000，也就是8月7日距离现在还有2678308秒
      // 1s=1000ms
      var chas=parseInt(cha/1000);//2678308
      // 接下来就需要将这个秒数换算成 x天x时x分x秒
  
      var day=parseInt(chas/3600/24);//得到多少天了
      // 土方法：chas-day*86400=
  
      
  
      var hours=parseInt(chas/3600%24);//小时
      
	  if(hours<10){
		  hours='0'+hours;
	  }else{
		  hours=hours;
	  }
  
      // 
      var min=parseInt(chas%3600/60);//分钟
      if(min<10){
      		  min='0'+min;
      }else{
      		  min=min;
      }
  
      var sec=chas%60;
	  if(sec<10){
	  		  sec='0'+sec;
	  }else{
	  		  sec=sec;
	  }
      
  
      // console.log("距离还剩："+day+"天"+hours+"时"+min+"分"+sec+"秒");
      // document.getElementById("box").innerText="距离2020年8月7日还剩："+day+"天"+hours+"时"+min+"分"+sec+"秒"
	  document.querySelector('.day').innerText=hours;
	  document.querySelector('.hours').innerText=min;
	  document.querySelector('.sec').innerText=sec;
	  
  }, 1000);
  
  function getStyle(obj,name){
  	return window.getComputedStyle?getComputedStyle(obj,null)[name]:obj.currentStyle[name];
  	
  }
  var slide2ul=document.querySelector('.slide2ul');
  var prev2=document.querySelector('.prev2');
  var next2=document.querySelector('.next2');
prev2.onclick=function(){
	clearInterval(timer);
	timer=setInterval(function(){
		var oldvalue=parseInt(getStyle(slide2ul,'left'));
		var newvalue=oldvalue-10;
		if(newvalue<-802){
			newvalue=0;
		}
		slide2ul.style.left=newvalue+'px';
		if(newvalue==-800){
			clearInterval(timer);
		}
	},30)
}


next2.onclick=function(){
	clearInterval(timer);
	timer=setInterval(function(){
		var oldvalue=parseInt(getStyle(slide2ul,'left'));
		var newvalue=oldvalue+10;
		if(newvalue>800){
			newvalue=800;
		}
		slide2ul.style.left=newvalue+'px';
		if(newvalue==0){
			clearInterval(timer);
		}
	},30)
	
};



function slidee(){
			var pic1=document.querySelectorAll('.pic1');
			var hongdian=document.querySelectorAll('.hongdian span');
			var index=0;
			var next3=document.getElementById('next3');
			next3.onclick=function(){
				index++;
				if(index>1){
					index=0;
				}
				for(var i=0;i<pic1.length;i++){
					pic1[i].className='pic1';
					hongdian[i].id='';
				}
				pic1[index].className='pic1 active2';
				hongdian[index].id='red1';
			}
			
			// for(var i=0;i<hongdian.length;i++){
			// 	hongdian[i].setAttribute('index',i);
			// 	hongdian[i].onclick=function(){
			// 		index=this.getAttribute('index');
			// 		for(var i=0;i<pic1.length;i++){
			// 			pic1[i].className='pic1';
			// 		}
			// 		pic1[index].className='pic1 active2';
			// 		for (var j=0;j<hongdian.length;j++) {
			// 			hongdian[j].className='';
			// 			this.className='red1';
			// 		}
			// 	}
			// }
			
			function go(){
				next3.onclick();
			}
			var timer=setInterval(go,3000)
			
			slide.onmouseover=function(){
								clearInterval(timer);
							};
			slide.onmouseout=function(){
								timer=setInterval(go,3000);
							}
		}
		slidee();



function tab1(tabBt,tabBd,eventtype){
	  var but=document.getElementById(tabBt);
	  var bd=document.getElementById(tabBd);
	  var butList=but.children;  //所有按钮
	  var bdList=bd.children;    //所有要切换的页面
	  for(var i=0;i<butList.length;i++){
		  butList[i].index=i;
		  butList[i][eventtype]=function(e){
			  e.preventDefault();
			  for(var j=0;j<bdList.length;j++){
				  if(j==this.index){
					  bdList[this.index].style.display='block';
					  this.className='tablk tabred';//要显示的样式
				  }else{
					  bdList[j].style.display='none';
					  butList[j].className='tablk';
				  }
			  }
		  }
	  }
	  
  }
  
  tab1("tabA","tabB","onmouseover");
  
  
  
  (function () {
      // 获取父盒子（肯定有滚动条）
      var parent = document.getElementById('scroll');
      // 获取子盒子（高度肯定比父盒子大）
      var child1 = document.getElementById('scrollul');
      // var child2 = document.getElementById('child2');
      // 第一个子盒子内容复制一遍给第二个子盒子，产生循环视觉，辅助作用
      // 可以注释下这条代码，看会出现什么情况
      // child2.innerHTML = child1.innerHTML;
      // 设置定时器，时间即为滚动速度
      var timer=setInterval(go, 20);
	  function go() {
	     if(parent.scrollLeft >= 510) {
	         parent.scrollLeft  = 0;
	     } else {
	         // 如果存在网页缩放，很有可能没有效果，但是else部分的代码会执行
	         // 原因：刚才讲到的scrollTop三个注意中标黄的一条
	         // 设置scrollTop的值小于0，即scrollTop被设为0
	         // 可以缩放跑一下，然后不刷新的状态下恢复百分之百跑一下，再缩放，打印scrollTop的值
	         // 你会发现正常尺寸执行时打印的第一个值不是加法，而是减法，即scrollTop++增加负值
	         // 这样的话就对应上了scrollTop的注意点了，增加的值小于0，就被设为0
	         parent.scrollLeft ++;
	  			 
	     }
	  }
	    parent.onmouseover=function(){
			clearInterval(timer);
		}
		parent.onmouseout=function(){
			timer=setInterval(go,20);
		}
	  
  })();
  
  //推荐的tab切换
  function tab2(tabBt,tabBd,eventtype){
  	  var but=document.querySelectorAll(tabBt);
  	  var bd=document.getElementById(tabBd);
	  var jx=document.querySelectorAll('.tuijian2>span');
  	  var butList=but;  //所有按钮
  	  var bdList=bd.children;    //所有要切换的页面
  	  for(var i=0;i<butList.length;i++){
  		  butList[i].index=i;
  		  butList[i][eventtype]=function(e){
  			  e.preventDefault();
  			  for(var j=0;j<bdList.length;j++){
  				  if(j==this.index){
  					  bdList[this.index].style.display='block';
  					  jx[this.index].className='jingxuan jingxuan1';//要显示的样式
					  jx[this.index].nextElementSibling.className='cai red ml5';
					  jx[this.index].nextElementSibling.id='';
  				  }else{
  					  bdList[j].style.display='none';
  					  // this.children[1].id='hui';
					  jx[j].className='jingxuan';
					  jx[j].nextElementSibling.id='hui';
  				  }
  			  }
  		  }
  	  }
  	  
    }
    
    tab2(".tuijian2","tabtuijian","onclick");
	
	
	// 右边固定栏
	
	var fixul=document.querySelector('fixul');
	// var nTop=getPos(fixul).top
	window.onscroll=function(){
		var top=document.documentElement.scrollTop;
		if(top>1000){
			fixul.className='fixed';
		}else{
			fixul.className='';
		}
	}
	
	